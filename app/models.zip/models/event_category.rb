class EventCategory < ApplicationRecord
  has_many :events
end
