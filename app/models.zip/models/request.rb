class Request < ApplicationRecord
  belongs_to :user
  belongs_to :category_request
end
